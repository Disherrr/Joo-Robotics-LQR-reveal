from pybricks.tools import run_task, wait, multitask
from robot_async_actions import fwd, bwd, turn_point, turn_swing, fwd_line,bwd_line
from pybricks.parameters import Port, Direction, Stop
from robot_singleton import get_robot

# Singleton pattern for robot access
robot = get_robot()
hub = robot.hub
left_arm = robot.left_arm
right_arm = robot.right_arm
right_foot = robot.right_motor
left_foot= robot.left_motor
async def run_1():


    await wait(200)
    #right_arm.run_time(-150,500)

    await fwd(target_heading=0, final_angle=1270, start_speed=30, max_speed=90, end_speed=25, decel_start_angle=1000, accel_rate=0.05,reset_gyro=True,stall_stop=False)
    right_arm.stop()
    left_arm.stop()
    await turn_swing(target_heading= -42, active_motor='right', max_speed=80, min_speed=15, max_time= 800,reset_gyro=False)
    print("go")
    await fwd(target_heading=-42, final_angle=400, start_speed=30, max_speed=85, end_speed=40, decel_start_angle=200, accel_rate=0.03,reset_gyro=False,stall_stop=True)
    print('stop')
    left_foot.stop()
    right_foot.stop()
    await right_arm.run_angle(1000, 300)
    await turn_swing(target_heading= 0, active_motor='right', max_speed=80, min_speed=15, max_time= 800,reset_gyro=False)
    await bwd(target_heading= 0, final_angle=200, start_speed=30, max_speed=85, end_speed=20, decel_start_angle=100, accel_rate=0.1,reset_gyro=False)
    await left_arm.run_angle(1000,800)
    await bwd(target_heading= 0, final_angle=1000, start_speed=30, max_speed=95, end_speed=20, decel_start_angle=800, accel_rate=0.1,reset_gyro=False)
    
if __name__ == "__main__":
    run_task(run_1())
