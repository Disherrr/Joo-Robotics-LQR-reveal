from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch

hub = PrimeHub() 



left = Motor(Port.E,Direction.COUNTERCLOCKWISE)
right = Motor(Port.F)

sensor = ColorSensor(Port.A)

while True:
    c = sensor.color()
    print(c)
    wait(500)




'''
for x in range(4): # 4 번 반복하기 ( 아래쪽에 들여쓰기 된 애들만.. )

    left.run_angle(500,360,wait=False) #left.run_angle()이 실행시작하자마자 동작끝나는거 안기다림.
    right.run_angle(500,360)

    left.run_angle(-500,360,wait=False) #left.run_angle()이 실행시작하자마자 동작끝나는거 안기다림.
    right.run_angle(500,360)



#정사각형 그리기.....
'''