from pybricks.tools import run_task, wait, multitask
from robot_async_actions import fwd, bwd, turn_point, turn_swing
from robot_singleton import get_robot

# Singleton pattern for robot access
robot = get_robot()
hub = robot.hub
left_arm = robot.left_arm
right_arm = robot.right_arm
right_foot = robot.right_motor
left_foot= robot.left_motor

async def run_3():
    
    await wait(300)
    await fwd(target_heading=0, final_angle=500, start_speed=20, max_speed=95, end_speed=20, decel_start_angle=300, accel_rate=0.1,stall_stop=True)
    left_foot.stop()
    right_foot.stop()
    wait(300)
    await turn_point(target_heading=90, max_speed=50, min_speed=15, stop_threshold=0.1, max_time=1000,reset_gyro=False)
    await turn_point(target_heading=-90, max_speed=50, min_speed=15, stop_threshold=0.1, max_time=1000,reset_gyro=False)
    await turn_point(target_heading=0, max_speed=50, min_speed=15, stop_threshold=0.1, max_time=1000,reset_gyro=False)
    
if __name__ == "__main__":
    run_task(run_3())

