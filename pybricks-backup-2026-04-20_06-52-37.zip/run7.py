from pybricks.tools import run_task, wait, multitask
from robot_async_actions import fwd, bwd, turn_point, turn_swing
from robot_singleton import get_robot
from pybricks.parameters import Port, Direction, Stop
# Singleton pattern for robot access
robot = get_robot()
hub = robot.hub
left_arm = robot.left_arm
right_arm = robot.right_arm
right_foot = robot.right_motor
left_foot = robot.left_motor

async def run_7():
    
    
    await left_arm.run_angle(1000,200,Stop.COAST)
    left_arm.run_angle(300,100,Stop.COAST)
    await bwd(target_heading=0, final_angle=30, start_speed=20, max_speed=50, end_speed=20, decel_start_angle=20, accel_rate=0.03,reset_gyro=True,stall_stop=True)
    left_foot.stop()
    right_foot.stop()
    await wait(400)
    await turn_swing(target_heading=-61, active_motor='right', max_speed=60, min_speed=15,  max_time=700,reset_gyro=True)
    await fwd(target_heading=-61, final_angle=1470, start_speed=20, max_speed=70, end_speed=20, decel_start_angle=1150, accel_rate=0.03,reset_gyro=False,stall_stop=True)
    await turn_point(target_heading=-51, max_speed=40, min_speed=15,  max_time=700,reset_gyro=False)
    await left_arm.run_angle(-1000,155,Stop.HOLD)
    await left_arm.run_angle(1000,155,Stop.HOLD)
    await left_arm.run_angle(-1000,290,Stop.HOLD)
    #await turn_swing(target_heading=-45, active_motor='left', max_speed=60, min_speed=15,  max_time=700,reset_gyro=False)
    #await turn_swing(target_heading=-55, active_motor='left', max_speed=40, min_speed=15,  max_time=700,reset_gyro=False)
    #await left_arm.run_angle(-1000,170,Stop.HOLD)
    await bwd(target_heading=-51, final_angle=460, start_speed=30, max_speed=90, end_speed=25, decel_start_angle=200, accel_rate=0.1,reset_gyro=False)
    await turn_point(target_heading=-180, max_speed=60, min_speed=15,  max_time=800,reset_gyro=False)
    await fwd(target_heading=-180, final_angle=260, start_speed=20, max_speed=60, end_speed=40, decel_start_angle=150, accel_rate=0.1,reset_gyro=False,stall_stop=True)
    await turn_swing(target_heading=-180, active_motor='left',max_speed=60, min_speed=15,  max_time=500,reset_gyro=False)
    await turn_point(target_heading=-190,max_speed=90, min_speed=15,  max_time=400,reset_gyro=False)
    right_foot.dc(50)
    await right_arm.run_angle(1000,2500,Stop.COAST)
    await turn_swing(target_heading=-70, active_motor='right',max_speed=90, min_speed=15,  max_time=800,reset_gyro=False)
    await bwd(target_heading=-70, final_angle=1200, start_speed=30, max_speed=95, end_speed=25, decel_start_angle=1100, accel_rate=0.1,reset_gyro=False)
    
if __name__ == "__main__":
    run_task(run_7())

