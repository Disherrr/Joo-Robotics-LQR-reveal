from pybricks.tools import run_task, wait, multitask
from robot_async_actions import fwd, bwd, turn_point, turn_swing
from robot_singleton import get_robot
from pybricks.robotics import DriveBase

# Singleton pattern for robot access
robot = get_robot()
hub = robot.hub
left_arm = robot.left_arm
right_arm = robot.right_arm

drive_base = DriveBase(robot.left_motor, robot.right_motor, wheel_diameter=62.4,axle_track=180)

async def run_2():
    await wait(200)
    await bwd(target_heading=0, final_angle=300, start_speed=30, max_speed=90, end_speed=45, decel_start_angle=90, accel_rate=0.1,reset_gyro=True,stall_stop=True)
    await left_arm.run_angle(1000, 150)
    await wait(500)
    await left_arm.run_angle(-1000, 150)
    #drive_base.settings(1000,1000)
    #await drive_base.straight(500)
    await fwd(target_heading=1, final_angle=200, start_speed=30, max_speed=50, end_speed=45, decel_start_angle=100, accel_rate=0.1,reset_gyro=False,stall_stop=False)
    await fwd(target_heading=1, final_angle=900, start_speed=45, max_speed=90, end_speed=45, decel_start_angle=800, accel_rate=0.03,reset_gyro=False,stall_stop=False)
    
    await wait(200)
    await fwd(target_heading=0, final_angle=480, start_speed=20, max_speed=75, end_speed=30, decel_start_angle=200, accel_rate=0.1)
    await left_arm.run_angle(-1000, 680)
    await fwd(target_heading=0, final_angle=270, start_speed=20, max_speed=35, end_speed=30, decel_start_angle=50, accel_rate=0.1,reset_gyro=False)
    #await bwd(target_heading=0, final_angle=20, start_speed=20, max_speed=30, end_speed=20, decel_start_angle=5, accel_rate=0.1,reset_gyro=False,stall_stop=False)
    await left_arm.run_angle(-1000, 550)
    #await left_arm.run_time(1000, 500)

    await turn_point(target_heading=-90, max_speed=50, min_speed=15, stop_threshold=0.1, max_time=1000,reset_gyro=False)
    
    await turn_swing(target_heading= -138, active_motor='left', max_speed=50, min_speed=15, stop_threshold=0.1, max_time=800,reset_gyro=False)
    await turn_swing(target_heading=-90, active_motor='right', max_speed=50, min_speed=15, stop_threshold=0.1, max_time=800,reset_gyro=False)

    await bwd(target_heading=-90, final_angle=500, start_speed=40, max_speed=60, end_speed=50, decel_start_angle=380, accel_rate=0.1,reset_gyro=False,stall_stop=False)
    await wait(700)
    await fwd(target_heading=0, final_angle=325, start_speed=20, max_speed=70, end_speed=20, decel_start_angle=250, accel_rate=0.03)
    await turn_point(target_heading=120, max_speed=50, min_speed=15, stop_threshold=0.1, max_time=900)
    #await turn_swing(target_heading= 130, active_motor='right', max_speed=90, min_speed=15, stop_threshold=0.1, max_time=1000)
    await bwd(target_heading=0, final_angle=850, start_speed=30, max_speed=95, end_speed=30, decel_start_angle=700, accel_rate=0.1)
    
if __name__ == "__main__":
    run_task(run_2())
