from pybricks.hubs import PrimeHub
from pybricks.tools import wait
from pybricks.parameters import Button,Color
from run1 import run_1
from run2 import run_2
from run3 import run_3
from run4 import run_4
from run5 import run_5
from run6 import run_6
from run7 import run_7
from run8 import run_8
hub = PrimeHub()

# 실행할 run 모듈들의 목록
# 실행할 run 모듈들의 목록 (필요 없음)
# run_modules = []

# 다음 실행을 위한 현재 인덱스
current_run_index = 0

from robot_singleton import get_robot
robot = get_robot()

# 모터 객체 초기화
motor_a = robot.left_arm
motor_b = robot.right_arm
motor_c = robot.left_motor
motor_d = robot.right_motor
hub.light.on(Color.BLUE)
def wait_for_button_press():
    global current_run_index
    """
    허브의 왼쪽 버튼이 눌릴 때까지 대기합니다.
    """
        # 대기 상태에서 모든 모터를 coast 상태로 유지합니다.
    motor_a.stop()  # 모터를 coast 상태로 설정
    motor_b.stop()  # 모터를 coast 상태로 설정
    motor_c.stop()  # 모터를 coast 상태로 설정
    motor_d.stop()  # 모터를 coast 상태로 설정

    while True:
        pressed_buttons = hub.buttons.pressed()
        # 오른쪽 버튼이 눌리면 다음 태스크로 이동합니다.
        if Button.RIGHT in pressed_buttons:
            current_run_index = (current_run_index + 1) % 8
            hub.display.number(11*(current_run_index + 1))
            wait(200)
        # 왼쪽 버튼이 눌리면 실행 준비 상태로 전환합니다.
        elif Button.LEFT in pressed_buttons:
            return
        wait(50)
        # 다음 실행 파일의 순서를 허브 매트릭스에 표시합니다.
        hub.display.number(11*(current_run_index + 1))
        wait(10)

from pybricks.tools import run_task

def main():
    global current_run_index
    
    # 모든 run이 완료될 때까지 반복합니다.
    while current_run_index < 8:
        # 왼쪽 버튼이 눌리기를 기다립니다.
        wait_for_button_press()
        
        # 현재 run 모듈을 실행합니다.
        if current_run_index == 0:
            run_task(run_1())
        elif current_run_index == 1:
            run_task(run_3())
        elif current_run_index == 2:
            run_task(run_2())
        elif current_run_index == 3:
            run_task(run_4())
        elif current_run_index == 4:
            run_task(run_5())
        elif current_run_index == 5:
            run_task(run_6())
        elif current_run_index == 6:
            run_task(run_7())
        elif current_run_index == 7:
            run_task(run_8())
        # 다음 run을 가리키도록 인덱스를 증가시킵니다.
        current_run_index += 1

# 메인 함수를 시작합니다.
if __name__ == "__main__":
    main()
