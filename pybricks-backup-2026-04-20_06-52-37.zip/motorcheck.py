from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor
from pybricks.parameters import Port, Color
from pybricks.tools import wait

# Инициализация хаба
hub = PrimeHub()

# Карта доступных портов
PORT_MAP = {
    Port.A: "A",
    Port.B: "B",
    Port.C: "C",
    Port.D: "D",
    Port.E: "E",
    Port.F: "F"
}

detected_motors = {}

hub.light.on(Color.YELLOW)
print("=== СКАНИРОВАНИЕ ПОРТОВ (Pybricks API) ===")

# 1. Опросить каждый порт
for port_obj, port_name in PORT_MAP.items():
    try:
        # Пытаемся инициализировать мотор на порту
        motor = Motor(port_obj)
        angle = motor.angle()
        detected_motors[port_name] = motor
        print(f"[+] Порт {port_name}: МОТОР ОБНАРУЖЕН (Текущий угол: {angle}°)")
    except OSError:
        # Если к порту ничего не подключено или подключен датчик
        print(f"[ ] Порт {port_name}: Не найден")

print("\n=== ТЕСТИРОВАНИЕ ВРАЩЕНИЯ И ИНДИКАЦИЯ ===")

if not detected_motors:
    hub.light.on(Color.RED)
    print("[-] Ошибка: Ни один мотор не обнаружен.")
else:
    hub.light.on(Color.GREEN)
    
    # 2. Прогнать тест движения для каждого найденного мотора
    for port_name, motor in detected_motors.items():
        print(f"-> Запуск теста на порту [{port_name}]...")
        
        # Поворот на 90 градусов со скоростью 300 град/сек и возврат обратно
        motor.run_angle(speed=300, rotation_angle=90)
        wait(200)
        motor.run_angle(speed=300, rotation_angle=-90)
        wait(300)

print("\n=== ИТОГИ ПРОВЕРКИ ===")
print("Подключенные порты с моторами:", list(detected_motors.keys()))