from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor
from pybricks.parameters import Port, Direction, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, hub_menu

hub = PrimeHub()

while not hub.imu.ready():
    wait(10)
hub.imu.reset_heading(0)

left_motor = Motor(Port.C, Direction.COUNTERCLOCKWISE)
right_motor = Motor(Port.A, Direction.CLOCKWISE)
arm_left = Motor(Port.B)
arm_right = Motor(Port.D)

TRACK = 165 
drive_base = DriveBase(left_motor, right_motor, wheel_diameter=62.4, axle_track=TRACK)
drive_base.use_gyro(True)

drive_base.settings(
    straight_speed=600, 
    straight_acceleration=400, 
    turn_rate=600, 
    turn_acceleration=400
)

def move_precise(distance):
    drive_base.straight(distance, then=Stop.HOLD, wait=True)
    wait(100)

def turn_precise(angle):
    drive_base.turn(angle, then=Stop.HOLD, wait=True)
    wait(100)

def pivot_right(angle):
    target_angle = angle * (TRACK / 62.4) * 2
    left_motor.run_angle(500, target_angle)
    drive_base.reset()

def pivot_left(angle):
    target_angle = angle * (TRACK / 62.4) * 2
    right_motor.run_angle(500, target_angle)
    drive_base.reset()

def mission_1():
    arm_right.run_angle(500, 500, wait=False)
    move_precise(220)
    turn_precise(90)
    move_precise(620)
    turn_precise(45)
    move_precise(110)
    arm_right.run_angle(500, -500)
    arm_right.run_angle(500, 550)
    arm_left.run_angle(700, -1300)
    pivot_left(-65)
    pivot_right(-50)
    turn_precise(90)
    move_precise(750)

def mission_2():
    arm_right.run_angle(500, -400, wait=False)
    move_precise(150)
    turn_precise(-53)
    move_precise(270)
    arm_left.run_angle(500, 200)
    move_precise(170)
    arm_left.run_angle(500,-90)
    arm_right.run_angle(500, 400)
    arm_left.run_angle(600, 200)
    move_precise(-200)
    move_precise(50)
    arm_right.run_angle(500, -500)
    move_precise(-300)

def mission_3():
    arm_right.run_angle(600, -170, wait=False)
    move_precise(410)
    arm_right.run_angle(600, 170)
    arm_right.run_angle(600, -170)
    arm_right.run_angle(600, 170)
    arm_right.run_angle(600, -170)
    arm_right.run_angle(600, 170)
    arm_right.run_angle(600, -170)
    arm_right.run_angle(600, 170)
    move_precise(-350)

def mission_4():
    move_precise(270)
    turn_precise(-90)
    move_precise(700)
    turn_precise(-101)
    move_precise(220)
    wait(800)
    arm_left.run_angle (500, 1300)
    move_precise(-170)
    turn_precise(132)
    arm_right.run_angle(500, -240)
    move_precise(230)
    pivot_right(10)
    arm_right.run_angle(600, 400)
    move_precise(-80)
    turn_precise(-67)
    move_precise(700)

def mission_5():
    arm_right.run_angle(200, -150, wait=False)
    move_precise(800)
    turn_precise(190)
    move_precise(-180)
    pivot_right(-3)
    arm_right.run_angle(300, 150, wait=False)
    move_precise(5)
    turn_precise(-93)
    drive_base.settings(straight_speed=80, straight_acceleration=50)
    move_precise(200)
    arm_left.run_angle(400, -350, wait=False)
    arm_right.run_angle(100, -150)
    drive_base.settings(straight_speed=600, straight_acceleration=400)
    move_precise(-150)
    turn_precise(105)
    move_precise(800)

def mission_6():
    move_precise(750)
    turn_precise(-49)
    move_precise(50)
    move_precise(20)
    arm_right.run_angle(500, 500)
    move_precise(110)
    arm_right.run_angle(500, -500)
    move_precise(-150)
    turn_precise(55)
    move_precise(-700)

def mission_7():
    move_precise(520)
    arm_right.run_angle(500, 450)
    move_precise(-550)

def mission_8():
    move_precise(200)
    turn_precise(30)
    move_precise(300)
    pivot_right(5)
    move_precise(-200)

menu_options = ["1", "2", "3", "4", "5", "6", "7","8"]
current_index = 0

while True:
    choice = hub_menu(*menu_options[current_index:], *menu_options[:current_index])
    
    mission_num = int(choice)
    
    if choice == "1":
        mission_1()
    elif choice == "2":
        mission_2()
    elif choice == "3":
        mission_3()
    elif choice == "4":
        mission_4()
    elif choice == "5":
        mission_5()
    elif choice == "6":
        mission_6()
    elif choice == "7":
        mission_7()
    elif choice == "8":
        mission_8()
    
    current_index = mission_num % 8
    
    drive_base.stop()
    wait(200)