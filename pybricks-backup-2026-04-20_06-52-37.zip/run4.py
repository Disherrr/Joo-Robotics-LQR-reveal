from pybricks.tools import run_task, wait, multitask
from robot_async_actions import fwd, bwd, turn_point, turn_swing
from robot_singleton import get_robot
from pybricks.parameters import Port, Direction, Stop
# Singleton pattern for robot access
robot = get_robot()
hub = robot.hub
left_arm = robot.left_arm
right_arm = robot.right_arm

async def run_4():
    
    await wait(500)
    left_arm.dc(-30)
    await fwd(target_heading=0, final_angle=1287, start_speed=20, max_speed=90, end_speed=20, decel_start_angle=900, accel_rate=0.05,stall_stop=False)
    await turn_swing(target_heading=90, active_motor='left', max_speed=70, min_speed=15, stop_threshold=0.1, max_time=900,reset_gyro=False)
    await fwd(target_heading=90, final_angle=350, start_speed=20, max_speed=75, end_speed=20, decel_start_angle=150, accel_rate=0.1,reset_gyro=False,stall_stop=False)
    
    #await multitask(left_arm.run_angle(-1000, 900),right_arm.run_angle(1000, 600))
    await right_arm.run_angle(400, 600)
    await right_arm.run_angle(-1000, 700)
    left_arm.stop()
    await fwd(target_heading=90, final_angle=330, start_speed=20, max_speed=40, end_speed=20, decel_start_angle=200, accel_rate=0.03,reset_gyro=False,stall_stop=False)
    
    await fwd(target_heading=90, final_angle=900, start_speed=20, max_speed=95, end_speed=20, decel_start_angle=600, accel_rate=0.1,reset_gyro=False,stall_stop=False)
    await turn_swing(target_heading=135, active_motor='left', max_speed=70, min_speed=15, stop_threshold=0.1, max_time=600,reset_gyro=False)
    await fwd(target_heading=135, final_angle=500, start_speed=20, max_speed=70, end_speed=30, decel_start_angle=300, accel_rate=0.1,reset_gyro=False)
    await turn_swing(target_heading=135, active_motor='left',max_speed=70, min_speed=15, stop_threshold=0.1, max_time=500,reset_gyro=False)
    #await bwd(target_heading=135, final_angle=30, start_speed=15, max_speed=35, end_speed=20, decel_start_angle=20, accel_rate=0.03,reset_gyro=False) 
    #await right_arm.run_angle(1000, 500)
    #await right_arm.run_angle(-1000, 600)
    await bwd(target_heading=135, final_angle=90, start_speed=25, max_speed=55, end_speed=20, decel_start_angle=50, accel_rate=0.1,reset_gyro=False)
    left_arm.run_angle(1000,1200)
    await turn_swing(target_heading=90, active_motor='left', max_speed=90, min_speed=15, stop_threshold=0.1, max_time=600,reset_gyro=False)
    await fwd(target_heading=90, final_angle=500, start_speed=20, max_speed=95, end_speed=20, decel_start_angle=300, accel_rate=0.1,reset_gyro=False,stall_stop=False)
    #left_arm.run_angle(1000,1100)
    await turn_swing(target_heading=185, active_motor='left', max_speed=90, min_speed=15, stop_threshold=0.1, max_time=900,reset_gyro=False)
    await turn_swing(target_heading=90, active_motor='right', max_speed=90, min_speed=15, stop_threshold=0.1, max_time=900,reset_gyro=False)
    
    await fwd(target_heading=90, final_angle=400, start_speed=20, max_speed=45, end_speed=20, decel_start_angle=300, accel_rate=0.1,reset_gyro=False,stall_stop=True)
    await left_arm.run_angle(1000,5000)
    await bwd(target_heading=90, final_angle=150, start_speed=25, max_speed=55, end_speed=20, decel_start_angle=50, accel_rate=0.1,reset_gyro=False)
    await turn_point(target_heading=170, max_speed=70, min_speed=15, stop_threshold=0.1, max_time=700,reset_gyro=False)
    await fwd(target_heading=170, final_angle=900, start_speed=20, max_speed=90, end_speed=20, decel_start_angle=800, accel_rate=0.1,reset_gyro=False,stall_stop=False)
if __name__ == "__main__":
    run_task(run_4())
