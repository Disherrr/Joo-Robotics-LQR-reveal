from pybricks.tools import run_task, wait, multitask
from robot_async_actions import fwd, bwd, turn_point, turn_swing, 
from robot_singleton import get_robot

# Singleton pattern for robot access
robot = get_robot()
hub = robot.hub
left_arm = robot.left_arm
right_arm = robot.right_arm

async def turn_test():
    robot = get_robot()  # Robot 인스턴스를 가져옵니다.
    stopwatch = robot.get_stopwatch()  # 인스턴스 메서드로 stopwatch 호출
    stopwatch.reset()  # StopWatch 초기화 및 시작

    #await turn_swing(target_heading=-90, active_motor='right', max_speed=90, min_speed=15, stop_threshold=0.1, max_time=2000,reset_gyro=False)
    await turn_point(target_heading=-90, max_speed=50, min_speed=15, stop_threshold=0.1, max_time=1000,reset_gyro=True)   
    
if __name__ == "__main__":
    run_task(turn_test())
