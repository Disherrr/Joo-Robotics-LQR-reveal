# -*- coding: utf-8 -*-
"""
Порты: A,B — колёса | C,D — насадки | E,F — датчики цвета (лев., прав.)
Меню:  ПРАВАЯ кнопка — следующая миссия, ЛЕВАЯ — старт,
       любая кнопка — прервать миссию, ЦЕНТР — остановить программу
"""

from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor
from pybricks.parameters import Port, Direction, Axis, Button, Color, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch
from umath import atan2, pi

# ---------------------------- настройки --------------------------------------
LEFT_DIR = Direction.COUNTERCLOCKWISE
RIGHT_DIR = Direction.CLOCKWISE
ATT1_DIR = Direction.CLOCKWISE
ATT2_DIR = Direction.CLOCKWISE

# Корректные геометрия и параметры движения
WHEEL_DIAMETER = 62.4     # мм
AXLE_TRACK = 115.0        # мм
STRAIGHT_SPEED = 250      # мм/с
STRAIGHT_ACCEL = 500
TURN_RATE = 120           # град/с
TURN_ACCEL = 300

ATT1_HOME_DIR = -1        # сторона упора насадки 1 (+1 / -1)
ATT2_HOME_DIR = -1
ATT1_TRAVEL = 180         # рабочий ход, град
ATT2_TRAVEL = 180
ATT_SPEED = 300
ATT_HOME_SPEED = 200
ATT_HOME_DUTY = 40

LINE_SPEED = 180          # мм/с
LINE_KP = 1.8             # Оптимизированный пропорциональный коэффициент
LINE_KI = 0.0
LINE_KD = 0.4             # Оптимизированный дифференциальный коэффициент
LINE_TURN_MAX = 180
LINE_MAX_DIST = 1500      # мм
LINE_MIN_DIST = 100       # мм
LINE_STOP_LEVEL = 25      # оба датчика темнее — перекрёсток

# Баланс
K_TH = 2.4                # по углу
K_W = 0.10                # по угл. скорости
K_V = 0.010               # по скорости колёс
K_X = 0.006               # по положению колёс
TRIM = 0.0
X_ERR_MAX = 720.0
DEADBAND = 2.0
V_NOMINAL = 8000.0
ALPHA = 0.99
LOOP_MS = 10
CALIB_MS = 1000
YAW_KP = 1.0
YAW_KI = 0.10
YAW_KD = 0.04
YAW_OUT_MAX = 25.0
YAW_I_MAX = 15.0
FALL_ANGLE = 35.0
FALL_TIME_MS = 150
SAT_TIME_MS = 1500

GYRO_AXIS = Axis.Y
GYRO_SIGN = 1.0
ACC_SIGN = -1.0
YAW_SIGN = 1.0
RAD2DEG = 180.0 / pi


# ---------------------------- утилиты ----------------------------------------
def clamp(value, low, high):
    return low if value < low else high if value > high else value


def sign(value):
    return 1.0 if value > 0 else -1.0 if value < 0 else 0.0


class PID:
    def __init__(self, kp, ki, kd, out_limit, i_limit, d_filter=0.3):
        self.kp, self.ki, self.kd = kp, ki, kd
        self.out_limit = out_limit
        self.i_limit = i_limit
        self.d_filter = d_filter
        self.reset()

    def reset(self, measurement=None):
        self.integral = 0.0
        self.prev = measurement
        self.d_value = 0.0

    def update(self, setpoint, measurement, dt):
        error = setpoint - measurement
        raw_d = 0.0
        if self.prev is not None and dt > 0:
            raw_d = -(measurement - self.prev) / dt
        self.prev = measurement
        self.d_value += self.d_filter * (raw_d - self.d_value)
        integral = clamp(self.integral + self.ki * error * dt,
                         -self.i_limit, self.i_limit)
        output = self.kp * error + integral + self.kd * self.d_value
        if abs(output) < self.out_limit or sign(error) != sign(output):
            self.integral = integral
        return clamp(output, -self.out_limit, self.out_limit)


# ---------------------------- оборудование -----------------------------------
hub = PrimeHub(top_side=Axis.Z, front_side=Axis.X)


def connect(name, maker):
    try:
        return maker()
    except OSError:
        print("Нет устройства:", name)
        hub.light.on(Color.RED)
        raise


left = connect("A", lambda: Motor(Port.F, LEFT_DIR))
right = connect("B", lambda: Motor(Port.B, RIGHT_DIR))
att1 = connect("C", lambda: Motor(Port.C, ATT1_DIR))
att2 = connect("D", lambda: Motor(Port.D, ATT2_DIR))
sensor_l = connect("E", lambda: ColorSensor(Port.E))
sensor_r = connect("F", lambda: ColorSensor(Port.A))

cal_black = [0.0, 0.0]
cal_white = [100.0, 100.0]


def aborted():
    pressed = hub.buttons.pressed()
    return Button.LEFT in pressed or Button.RIGHT in pressed


def wait_release():
    while hub.buttons.pressed():
        wait(10)


def stop_all():
    left.stop()
    right.stop()
    att1.stop()
    att2.stop()


def make_drive():
    while not hub.imu.ready():
        wait(10)
    drive = DriveBase(left, right, WHEEL_DIAMETER, AXLE_TRACK)
    drive.settings(STRAIGHT_SPEED, STRAIGHT_ACCEL, TURN_RATE, TURN_ACCEL)
    drive.use_gyro(True)
    drive.reset()
    return drive


def norm_reflection(value, i):
    span = cal_white[i] - cal_black[i]
    if span < 5:
        return clamp(value, 0, 100)
    return clamp((value - cal_black[i]) * 100.0 / span, 0, 100)


def read_gyro():
    return GYRO_SIGN * hub.imu.angular_velocity(GYRO_AXIS)


def read_acc_angle():
    ax = hub.imu.acceleration(Axis.X)
    az = hub.imu.acceleration(Axis.Z)
    return ACC_SIGN * atan2(ax, az) * RAD2DEG


def imu_calibrate():
    gyro_sum = acc_sum = 0.0
    count = 0
    timer = StopWatch()
    while timer.time() < CALIB_MS:
        gyro_sum += read_gyro()
        acc_sum += read_acc_angle()
        count += 1
        wait(5)
    return gyro_sum / count, acc_sum / count


# ---------------------------- миссии -----------------------------------------
def mission_straight_turn():
    """Движение по заданной траектории"""
    hub.light.on(Color.GREEN)
    drive = make_drive()
    drive.straight(500)
    drive.turn(90)
    drive.straight(200)
    drive.turn(-90)
    drive.straight(-700)
    drive.stop()


def mission_line_follow():
    """Езда по линии (два датчика)"""
    drive = make_drive()
    pid = PID(LINE_KP, LINE_KI, LINE_KD, LINE_TURN_MAX, LINE_TURN_MAX / 2)
    hub.light.on(Color.GREEN)
    timer = StopWatch()
    last = timer.time()
    while not aborted():
        now = timer.time()
        dt = max((now - last) / 1000.0, 0.001)
        last = now
        refl_l = norm_reflection(sensor_l.reflection(), 0)
        refl_r = norm_reflection(sensor_r.reflection(), 1)
        drive.drive(LINE_SPEED, pid.update(0.0, refl_r - refl_l, dt))
        dist = drive.distance()
        if dist >= LINE_MAX_DIST:
            break
        if (dist >= LINE_MIN_DIST and refl_l < LINE_STOP_LEVEL
                and refl_r < LINE_STOP_LEVEL):
            break
        wait(10)
    drive.stop()


def home_attachment(motor, home_dir):
    motor.run_until_stalled(home_dir * ATT_HOME_SPEED, Stop.HOLD, ATT_HOME_DUTY)
    motor.reset_angle(0)


def mission_attachments_home():
    """Сброс и калибровка насадок"""
    hub.light.on(Color.ORANGE)
    home_attachment(att1, ATT1_HOME_DIR)
    home_attachment(att2, ATT2_HOME_DIR)
    hub.light.on(Color.GREEN)


def mission_ports_check():
    """Мониторинг портов и аккумулятора"""
    hub.light.on(Color.CYAN)
    while not aborted():
        print("A:%d B:%d C:%d D:%d | E:%d | F:%d | %d мВ" % (
            left.angle(), right.angle(), att1.angle(), att2.angle(),
            sensor_l.reflection(), sensor_r.reflection(),
            hub.battery.voltage()))
        wait(200)


def mission_balance():
    """Балансировка робота"""
    while not hub.imu.ready():
        wait(10)
    hub.light.on(Color.YELLOW)
    gyro_bias, acc0 = imu_calibrate()
    left.reset_angle(0)
    right.reset_angle(0)
    hub.imu.reset_heading(0)
    hub.light.on(Color.GREEN)

    yaw_pid = PID(YAW_KP, YAW_KI, YAW_KD, YAW_OUT_MAX, YAW_I_MAX)
    yaw_pid.reset(0.0)
    theta = 0.0
    vbat = hub.battery.voltage()
    vbat_time = 0
    fall_ms = sat_ms = 0
    timer = StopWatch()
    last = timer.time()

    while not aborted():
        now = timer.time()
        dt = (now - last) / 1000.0
        last = now
        dt = clamp(dt if dt > 0 else LOOP_MS / 1000.0, 0.001, 0.05)

        gyro = read_gyro() - gyro_bias
        acc_angle = read_acc_angle() - acc0
        theta = ALPHA * (theta + gyro * dt) + (1.0 - ALPHA) * acc_angle

        x = (left.angle() + right.angle()) / 2.0 + theta
        v = (left.speed() + right.speed()) / 2.0 + gyro
        u = (K_TH * (theta - TRIM) + K_W * gyro
             + K_X * clamp(x, -X_ERR_MAX, X_ERR_MAX) + K_V * v)
        if u > 0.5:
            u += DEADBAND
        elif u < -0.5:
            u -= DEADBAND

        if now - vbat_time > 200:
            vbat = hub.battery.voltage()
            vbat_time = now
        if vbat > 0:
            u *= V_NOMINAL / vbat

        steer = yaw_pid.update(0.0, YAW_SIGN * hub.imu.heading(), dt)
        left.dc(clamp(u + steer, -100.0, 100.0))
        right.dc(clamp(u - steer, -100.0, 100.0))

        fall_ms = fall_ms + int(dt * 1000) if abs(theta) > FALL_ANGLE else 0
        sat_ms = sat_ms + int(dt * 1000) if abs(u) >= 100.0 else 0
        if fall_ms >= FALL_TIME_MS or sat_ms >= SAT_TIME_MS:
            break

        spent = timer.time() - now
        if spent < LOOP_MS:
            wait(LOOP_MS - spent)

    left.stop()
    right.stop()


# ---------------------------- облегченное меню -------------------------------
MISSIONS = [
    (mission_straight_turn, Color.GREEN),
    (mission_line_follow, Color.BLUE),
    (mission_attachments_home, Color.ORANGE),
    (mission_balance, Color.VIOLET),
    (mission_ports_check, Color.CYAN),
]


def show(index):
    hub.display.number(index + 1)
    hub.light.on(MISSIONS[index][1])


def run(index):
    try:
        MISSIONS[index][0]()
    except Exception as error:
        print("Ошибка:", repr(error))
        hub.light.on(Color.RED)
        wait(800)
    stop_all()
    wait_release()


index = 0
show(index)
while True:
    pressed = hub.buttons.pressed()
    if Button.RIGHT in pressed:
        wait_release()
        index = (index + 1) % len(MISSIONS)
        show(index)
    elif Button.LEFT in pressed:
        wait_release()
        run(index)
        show(index)
    wait(20)