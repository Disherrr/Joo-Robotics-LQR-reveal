from pybricks.tools import run_task, wait, multitask
from robot_async_actions import fwd, bwd, turn_point, turn_swing
from robot_singleton import get_robot
from pybricks.parameters import Port, Direction, Stop
# Singleton pattern for robot access
robot = get_robot()
hub = robot.hub
left_arm = robot.left_arm
right_arm = robot.right_arm
right_foot = robot.right_motor
left_foot = robot.left_motor

async def run_8():
    right_arm.dc(20)
    await bwd(target_heading=0, final_angle=30, start_speed=20, max_speed=50, end_speed=20, decel_start_angle=20, accel_rate=0.03,reset_gyro=True,stall_stop=True)
    left_foot.stop()
    right_foot.stop()
    await wait(400)
    await fwd(target_heading=0, final_angle=1450, start_speed=20, max_speed=90, end_speed=20, decel_start_angle=1100, accel_rate=0.1,reset_gyro=True,stall_stop=False)
    right_arm.reset_angle(0)
    right_arm.stop()
    await turn_point(target_heading=90, max_speed=90, min_speed=15, stop_threshold=0.1, max_time=600,reset_gyro=False)
    right_arm.run_target(300,-122)
    await bwd(target_heading=90, final_angle=670, start_speed=20, max_speed=90, end_speed=20, decel_start_angle=300, accel_rate=0.1,reset_gyro=False,stall_stop=False)
    #left_arm.run_angle(-1000,390)
    await turn_point(target_heading= 0, max_speed=90, min_speed=15, stop_threshold=0.1, max_time=600,reset_gyro=False)
    await left_arm.run_angle(-1000,390)
    await fwd(target_heading=0, final_angle=230, start_speed=20, max_speed=55, end_speed=20, decel_start_angle=100, accel_rate=0.1,reset_gyro=False,stall_stop=False)
    #right_arm.run_angle(1000,350)
    right_arm.run_angle(1000,120)
    await left_arm.run_angle(1000,390)
    await turn_swing(target_heading=45, active_motor='right', max_speed=90, min_speed=15, stop_threshold=0.1, max_time=400,reset_gyro=False)
    await bwd(target_heading=45, final_angle=600, start_speed=20, max_speed=90, end_speed=20, decel_start_angle=450, accel_rate=0.1,reset_gyro=False,stall_stop=False)
    left_arm.run_angle(-1000,390)
    await turn_point(target_heading=220, max_speed=50, min_speed=15, stop_threshold=0.1, max_time=1300,reset_gyro=False)
    await right_arm.run_angle(-300,220)
    right_arm.run_angle(1000,220)
    await bwd(target_heading=220, final_angle=100, start_speed=20, max_speed=95, end_speed=20, decel_start_angle=50, accel_rate=0.1,reset_gyro=False,stall_stop=False)
   
   
if __name__ == "__main__":
    run_task(run_8())

