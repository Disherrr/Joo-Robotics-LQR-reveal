from pybricks.hubs import PrimeHub

hub = PrimeHub()

volts = hub.battery.voltage() / 1000
print(volts)