from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor
from pybricks.parameters import Port, Direction
from pybricks.robotics import DriveBase
from pybricks.tools import wait

hub = PrimeHub()

while not hub.imu.ready():
    wait(10)
hub.imu.reset_heading(0)

# МОТОРЛАР МЕН ДАТЧИКТЕР
left_motor = Motor(Port.F, Direction.COUNTERCLOCKWISE)
right_motor = Motor(Port.B, Direction.CLOCKWISE)
left_sensor = ColorSensor(Port.A)   
right_sensor = ColorSensor(Port.E)  

TRACK = 165 
drive_base = DriveBase(left_motor, right_motor, wheel_diameter=62.4, axle_track=TRACK)
drive_base.use_gyro(True)

def follow_line_sharp_turns(speed, distance_to_travel):
    # Күрт бұрылыстар үшін Kp мен Kd мәндерін сәл өсірдік
    Kp = 2.0   # Сызыққа шұғыл қайту күші
    Ki = 0.0   
    Kd = 1.2   # Бұрылыстағы шайқалуды басатын тежегіш
    
    integral = 0
    last_error = 0
    
    # Сіздің картаңыздағы ақ түстің шамамен алынған мәні (егер одан жоғары болса, ақ деп есептейді)
    WHITE_VALUE = 80 
    
    drive_base.reset()
    
    while drive_base.distance() < distance_to_travel:
        left_val = left_sensor.reflection()
        right_val = right_sensor.reflection()
        
        # ЕСІМДЕ САҚТАУ СЕКЦИЯСЫ:
        # Егер екі датчик те ақ түсті көрсе (күрт бұрылыста сызық жоғалса)
        if left_val > WHITE_VALUE and right_val > WHITE_VALUE:
            # Соңғы белгілі қателікті (last_error) қолданамыз.
            # Ол роботты түзу жібермей, сызық жоғалған жаққа қарай күрт бұрады.
            error = last_error
        else:
            # Қалыпты жағдайда екі датчик айырмашылығы
            error = right_val - left_val
        
        # PID есептеулері
        P = error
        integral += error
        I = integral
        derivative = error - last_error
        D = derivative
        
        turn_rate = (Kp * P) + (Ki * I) + (Kd * D)
        
        # Роботты жүргізу
        drive_base.drive(speed, turn_rate)
        
        # Егер қателік 0 болмаса ғана соңғы қателік ретінде сақтаймыз
        if error != 0:
            last_error = error
            
        wait(10)
        
    drive_base.stop()

# ІСКЕ ҚОСУ
# Күрт бұрылыстары бар картада жылдамдықты басында 150-200-ден асырмаған жөн
follow_line_sharp_turns(150, 20000)
drive_base.stop()