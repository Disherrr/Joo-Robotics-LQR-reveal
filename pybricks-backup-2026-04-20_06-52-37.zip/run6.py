from pybricks.tools import run_task, wait, multitask
from robot_async_actions import fwd, bwd, turn_point, turn_swing
from robot_singleton import get_robot

# Singleton pattern for robot access
robot = get_robot()
hub = robot.hub
left_arm = robot.left_arm
right_arm = robot.right_arm
left_m = robot.left_motor
right_m = robot.right_motor
async def run_6():
    await wait(200)
    await bwd(target_heading=0, final_angle=30, start_speed=20, max_speed=50, end_speed=20, decel_start_angle=20, accel_rate=0.03,reset_gyro=True,stall_stop=True)
    left_m.stop()
    right_m.stop()
    await wait(400)
    right_arm.run_angle(-1000, 1300)
    await turn_swing(target_heading=-48, active_motor='right', max_speed=90, min_speed=15,  max_time=800,reset_gyro=True)
    await fwd(target_heading=-48, final_angle=650, start_speed=20, max_speed=90, end_speed=20, decel_start_angle=400, accel_rate=0.1,reset_gyro=False)
    await right_arm.run_angle(1000, 1300)
    await turn_swing(target_heading=-5, active_motor='left', max_speed=60, min_speed=35,  max_time=700,reset_gyro=False)
    await left_arm.run_angle(1000, 100)
    await left_arm.run_angle(-1000, 100)
    await turn_swing(target_heading=-60, active_motor='left', max_speed=90, min_speed=15,  max_time=800,reset_gyro=False)
    await bwd(target_heading=-60, final_angle=900, start_speed=25, max_speed=95, end_speed=20, decel_start_angle=800, accel_rate=0.1,reset_gyro=False)

 
if __name__ == "__main__":
    run_task(run_6())
