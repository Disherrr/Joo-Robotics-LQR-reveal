
from robot_singleton import get_robot
from pybricks.tools import StopWatch, wait
from pybricks.parameters import Color
import umath


# Singleton pattern for robot access
robot = get_robot()
hub = robot.hub
left_motor = robot.left_motor
right_motor = robot.right_motor
color1 = robot.left_color
async def fwd(target_heading, final_angle, start_speed, max_speed, end_speed, decel_start_angle, accel_rate, reset_gyro=True,stall_stop=True,stall_stop_delay=100):
    # 고정된 제어 상수
    kp_base = 3
    ki_base = 0.005
    adapt_rate = 0.0001
    loop_counter = 0
    stopwatch = StopWatch()
    last_movement_time = stopwatch.time()
    # 자이로 초기화 여부에 따라 리셋

    if reset_gyro:
        hub.imu.reset_heading(0)

    # 모터 초기화
    left_motor.reset_angle(0)
    right_motor.reset_angle(0)

    current_speed = abs(start_speed)
    max_speed = abs(max_speed)
    end_speed = abs(end_speed)
    accel_rate = abs(accel_rate)

    integral_error = 0
    prev_error = 0

    kp_min, kp_max = 0.5 * kp_base, 2 * kp_base
    ki_min, ki_max = 0.5 * ki_base, 2 * ki_base

    while abs(left_motor.angle()) < final_angle:
        left_angle = abs(left_motor.angle())
        remaining_distance = final_angle - left_angle

        # 가속 및 감속 처리
        if left_angle >= decel_start_angle:
            scale = remaining_distance / (final_angle - decel_start_angle)
            current_speed = end_speed + (max_speed - end_speed) * scale
        else:
            if current_speed < max_speed:
                current_speed += accel_rate
                current_speed = min(current_speed, max_speed)

        # 자이로 센서를 사용한 직진 유지
        error = hub.imu.heading() - target_heading
        integral_error += error

        # 적응형 제어: 오차에 따라 제어 상수를 조정
        kp = kp_base + adapt_rate * abs(error)
        ki = ki_base + adapt_rate * abs(integral_error)

        # 제어 상수를 최소/최대 범위로 제한
        kp = max(kp_min, min(kp, kp_max))
        ki = max(ki_min, min(ki, ki_max))

        # PI 제어로 모터 보정값 계산
        correction = kp * error + ki * integral_error

        loop_counter += 1
        if loop_counter % 100 == 0:
            await wait(1)  # Minimal delay to yield control without significant performance loss
        if stall_stop == True:
            if abs(left_angle-abs(right_motor.angle())) > stall_stop_delay :
                print("angle_stop")
                break
                
            current_time = stopwatch.time()
            left_sp = abs(left_motor.speed())
            if (current_time - last_movement_time) > 500 and left_sp < 100:
                print("low_speed_stop")
                #print("Left motor has not moved for 0.2 seconds, stopping.")
                break

            if left_sp > 100:
                last_movement_time = current_time
        # 모터 속도에 보정값 적용
        left_motor.dc(current_speed - correction)
        right_motor.dc(current_speed + correction)

    left_motor.hold()
    right_motor.hold()
    #print(loop_counter,final_angle)

async def bwd(target_heading, final_angle, start_speed, max_speed, end_speed, decel_start_angle, accel_rate, reset_gyro=True,kp_value=3,ki_value=0.005,kd_value=0,stall_stop=True):
    # 고정된 제어 상수
    kp_base = kp_value
    ki_base = ki_value
    kd_base = kd_value
    adapt_rate = 0.0001
    loop_counter = 0
    stopwatch = StopWatch()
    last_movement_time = stopwatch.time()

    # 자이로 초기화 여부에 따라 리셋
    if reset_gyro:
        hub.imu.reset_heading(0)

    # 모터 초기화
    left_motor.reset_angle(0)
    right_motor.reset_angle(0)

    current_speed = -abs(start_speed)
    max_speed = -abs(max_speed)
    end_speed = -abs(end_speed)
    accel_rate = abs(accel_rate)

    integral_error = 0
    prev_error = 0

    kp_min, kp_max = 0.5 * kp_base, 2 * kp_base
    ki_min, ki_max = 0.5 * ki_base, 2 * ki_base

    while abs(left_motor.angle()) < final_angle:
        left_angle = abs(left_motor.angle())
        remaining_distance = final_angle - left_angle

        # 가속 및 감속 처리
        if left_angle >= decel_start_angle:
            scale = remaining_distance / (final_angle - decel_start_angle)
            current_speed = end_speed + (max_speed - end_speed) * scale
        else:
            if current_speed > max_speed:
                current_speed -= accel_rate
                current_speed = max(current_speed, max_speed)

        # 자이로 센서를 사용한 직진 유지
        error = hub.imu.heading() - target_heading
        integral_error += error

        # 적응형 제어: 오차에 따라 제어 상수를 조정
        kp = kp_base + adapt_rate * abs(error)
        ki = ki_base + adapt_rate * abs(integral_error)

        # 제어 상수를 최소/최대 범위로 제한
        kp = max(kp_min, min(kp, kp_max))
        ki = max(ki_min, min(ki, ki_max))

        # PI 제어로 모터 보정값 계산
        correction = kp * error + ki * integral_error + kd_base*(error-prev_error)
        error = prev_error
        loop_counter += 1
        if loop_counter % 100 == 0:
            await wait(1)  # Minimal delay to yield control without significant performance loss
        if stall_stop == True:
            if abs(left_angle-abs(right_motor.angle())) > 100 :
                break
            current_time = stopwatch.time()
            left_sp = abs(left_motor.speed())
            if (current_time - last_movement_time) > 400 and left_sp < 100:
                #print("Left motor has not moved for 0.2 seconds, stopping.")
                break

            if left_sp > 100:
                last_movement_time = current_time
        # 모터 속도에 보정값 적용
        left_motor.dc(current_speed - correction)
        right_motor.dc(current_speed + correction)

    left_motor.hold()
    right_motor.hold()
    #print(loop_counter,final_angle)

async def turn_point(target_heading, reset_gyro=True, max_speed=80, min_speed=10, stop_threshold=0.05, max_time=1000):
    if reset_gyro:
        hub.imu.reset_heading(0)

    left_motor.reset_angle(0)
    right_motor.reset_angle(0)

    stopwatch = StopWatch()

    def state():
        theta = hub.imu.heading()
        theta_dot = hub.imu.angular_velocity()[2]
        return theta, theta_dot

    def lqr_control(current_state, target_heading, K):
        theta, theta_dot = current_state
        error = target_heading - theta
        feedback = K[0] * error + K[1] * theta_dot
        return feedback

    K = [8, 0.1]
    feedforward_gain = 0.3

    while True:
        current_state = state()
        feedback_input = lqr_control(current_state, target_heading, K)
        feedforward_input = feedforward_gain * (target_heading - current_state[0])
        control_input = feedback_input + feedforward_input

        if abs(control_input) < min_speed:
            control_input = min_speed if control_input > 0 else -min_speed
        control_input = max(min(control_input, max_speed), -max_speed)

        left_motor.dc(control_input)
        right_motor.dc(-control_input)

        if stopwatch.time() > max_time:
            break

        

    left_motor.brake()
    right_motor.brake()

    #await wait(500)
    #print(hub.imu.heading())

async def turn_swing(target_heading, active_motor, reset_gyro=True, max_speed=100, min_speed=10, stop_threshold=0.05, max_time=1000):


    
    if reset_gyro:
        hub.imu.reset_heading(0)

    left_motor.reset_angle(0)
    right_motor.reset_angle(0)

    stopwatch = StopWatch()

    def state():
        theta = hub.imu.heading()
        theta_dot = hub.imu.angular_velocity()[2]
        return theta, theta_dot

    def lqr_control(current_state, target_heading, K):
        theta, theta_dot = current_state
        error = target_heading - theta
        feedback = K[0] * error + K[1] * theta_dot
        return feedback

    K = [15, 0.5]
    feedforward_gain = 0.15

    while True:
        current_state = state()
        feedback_input = lqr_control(current_state, target_heading, K)
        feedforward_input = feedforward_gain * (target_heading - current_state[0])
        control_input = feedback_input + feedforward_input

        if abs(control_input) < min_speed:
            control_input = min_speed if control_input > 0 else -min_speed
        control_input = max(min(control_input, max_speed), -max_speed)

        if active_motor == 'left':
            left_motor.dc(control_input)
            right_motor.hold()
        elif active_motor == 'right':
            right_motor.dc(-control_input)
            left_motor.hold()

        if stopwatch.time() > max_time:
            break

        

    left_motor.brake()
    right_motor.brake()



####################################################################################
####################################################################################
####################################################################################
####################################################################################
####################################################################################
####################################################################################

async def fwd_line(target_heading, final_angle, start_speed, max_speed, end_speed, decel_start_angle,action_ang,accel_rate,stop_mode='lt',light_th= 20,  reset_gyro=True,stall_stop=True,stall_stop_delay=500):
    # 고정된 제어 상수
    kp_base = 3
    ki_base = 0.005
    adapt_rate = 0.0001
    loop_counter = 0
    stopwatch = StopWatch()
    last_movement_time = stopwatch.time()
    # 자이로 초기화 여부에 따라 리셋

    if reset_gyro:
        hub.imu.reset_heading(0)

    # 모터 초기화
    left_motor.reset_angle(0)
    right_motor.reset_angle(0)

    current_speed = abs(start_speed)
    max_speed = abs(max_speed)
    end_speed = abs(end_speed)
    accel_rate = abs(accel_rate)

    integral_error = 0
    prev_error = 0

    kp_min, kp_max = 0.5 * kp_base, 2 * kp_base
    ki_min, ki_max = 0.5 * ki_base, 2 * ki_base

    while abs(left_motor.angle()) < final_angle:
        left_angle = abs(left_motor.angle())
        remaining_distance = final_angle - left_angle
        
        if action_ang < left_angle:
            if (stop_mode == 'lt') and (await color1.reflection() < light_th): 
                print("dark")
                break
            if (stop_mode == 'gt') and (await color1.reflection() > light_th):
                print("light")
                break
        # 가속 및 감속 처리
        if left_angle >= decel_start_angle:
            scale = remaining_distance / (final_angle - decel_start_angle)
            current_speed = end_speed + (max_speed - end_speed) * scale
        else:
            if current_speed < max_speed:
                current_speed += accel_rate
                current_speed = min(current_speed, max_speed)

        # 자이로 센서를 사용한 직진 유지
        error = hub.imu.heading() - target_heading
        integral_error += error

        # 적응형 제어: 오차에 따라 제어 상수를 조정
        kp = kp_base + adapt_rate * abs(error)
        ki = ki_base + adapt_rate * abs(integral_error)

        # 제어 상수를 최소/최대 범위로 제한
        kp = max(kp_min, min(kp, kp_max))
        ki = max(ki_min, min(ki, ki_max))

        # PI 제어로 모터 보정값 계산
        correction = kp * error + ki * integral_error

        loop_counter += 1
        if loop_counter % 100 == 0:
            await wait(1)  # Minimal delay to yield control without significant performance loss
        if stall_stop == True:
            if abs(left_angle-abs(right_motor.angle())) > stall_stop_delay :
                print("angle_stop")
                break
                
            current_time = stopwatch.time()
            left_sp = abs(left_motor.speed())
            if (current_time - last_movement_time) > 500 and left_sp < 100:
                print("low_speed_stop")
                #print("Left motor has not moved for 0.2 seconds, stopping.")
                break

            if left_sp > 100:
                last_movement_time = current_time
        # 모터 속도에 보정값 적용
        left_motor.dc(current_speed - correction)
        right_motor.dc(current_speed + correction)

    left_motor.hold()
    right_motor.hold()
    #print(loop_counter,final_angle)

async def bwd_line(target_heading, final_angle, start_speed, max_speed, end_speed, decel_start_angle, action_ang ,accel_rate, stop_mode='lt',light_th= 20,reset_gyro=True,kp_value=3,ki_value=0.005,kd_value=0,stall_stop=True):
    # 고정된 제어 상수
    kp_base = kp_value
    ki_base = ki_value
    kd_base = kd_value
    adapt_rate = 0.0001
    loop_counter = 0
    stopwatch = StopWatch()
    last_movement_time = stopwatch.time()

    # 자이로 초기화 여부에 따라 리셋
    if reset_gyro:
        hub.imu.reset_heading(0)

    # 모터 초기화
    left_motor.reset_angle(0)
    right_motor.reset_angle(0)

    current_speed = -abs(start_speed)
    max_speed = -abs(max_speed)
    end_speed = -abs(end_speed)
    accel_rate = abs(accel_rate)

    integral_error = 0
    prev_error = 0

    kp_min, kp_max = 0.5 * kp_base, 2 * kp_base
    ki_min, ki_max = 0.5 * ki_base, 2 * ki_base

    while abs(left_motor.angle()) < final_angle:
        left_angle = abs(left_motor.angle())
        remaining_distance = final_angle - left_angle
        if action_ang < left_angle:
            if (stop_mode == 'lt') and (await color1.reflection() < light_th): 
                print("dark")
                break
            if (stop_mode == 'gt') and (await color1.reflection() > light_th):
                print("light")
                break
        # 가속 및 감속 처리
        if left_angle >= decel_start_angle:
            scale = remaining_distance / (final_angle - decel_start_angle)
            current_speed = end_speed + (max_speed - end_speed) * scale
        else:
            if current_speed > max_speed:
                current_speed -= accel_rate
                current_speed = max(current_speed, max_speed)

        # 자이로 센서를 사용한 직진 유지
        error = hub.imu.heading() - target_heading
        integral_error += error

        # 적응형 제어: 오차에 따라 제어 상수를 조정
        kp = kp_base + adapt_rate * abs(error)
        ki = ki_base + adapt_rate * abs(integral_error)

        # 제어 상수를 최소/최대 범위로 제한
        kp = max(kp_min, min(kp, kp_max))
        ki = max(ki_min, min(ki, ki_max))

        # PI 제어로 모터 보정값 계산
        correction = kp * error + ki * integral_error + kd_base*(error-prev_error)
        error = prev_error
        loop_counter += 1
        if loop_counter % 100 == 0:
            await wait(1)  # Minimal delay to yield control without significant performance loss
        if stall_stop == True:
            if abs(left_angle-abs(right_motor.angle())) > 100 :
                break
            current_time = stopwatch.time()
            left_sp = abs(left_motor.speed())
            if (current_time - last_movement_time) > 400 and left_sp < 100:
                #print("Left motor has not moved for 0.2 seconds, stopping.")
                break

            if left_sp > 100:
                last_movement_time = current_time
        # 모터 속도에 보정값 적용
        left_motor.dc(current_speed - correction)
        right_motor.dc(current_speed + correction)

    left_motor.hold()
    right_motor.hold()
    #print(loop_counter,final_angle)



async def fwd_lqr(
    target_heading, 
    final_angle, 
    start_speed, 
    max_speed, 
    end_speed, 
    decel_start_angle, 
    accel_rate, 
    reset_gyro=True, 
    K=[10, 0.3], 
    feedforward_gain=0.5, 
    bias=2  # 비대칭 보정값
):
    if reset_gyro:
        hub.imu.reset_heading(0)

    left_motor.reset_angle(0)
    right_motor.reset_angle(0)
    current_speed = abs(start_speed)
    previous_left_speed = 0
    previous_right_speed = 0
    previous_correction = 0

    def state():
        theta = hub.imu.heading()
        theta_dot = sum(hub.imu.angular_velocity()[2] for _ in range(5)) / 5  # 노이즈 평균화
        return theta, theta_dot

    def lqr_control(current_state, target_heading, K):
        theta, theta_dot = current_state
        error = target_heading - theta
        feedback = K[0] * error + K[1] * theta_dot
        return feedback

    while abs(left_motor.angle()) < final_angle:
        left_angle = abs(left_motor.angle())
        remaining_distance = final_angle - left_angle

        if left_angle >= decel_start_angle:
            scale = (remaining_distance / (final_angle - decel_start_angle))**3  # 부드러운 감속
            current_speed = max(end_speed, end_speed + (max_speed - end_speed) * scale)
        else:
            current_speed = min(current_speed + accel_rate, max_speed)

        # 최소 속도 유지
        min_speed = 25
        if current_speed < min_speed:
            current_speed = min_speed

        current_state = state()
        feedback_input = lqr_control(current_state, target_heading, K)
        feedforward_input = feedforward_gain * (target_heading - current_state[0])
        correction = feedback_input + feedforward_input

        # 저속 시 보정값 감소
        if current_speed < 35:
            correction *= 0.5
            feedforward_input *= 0.5

        # 보정값 변화율 제한
        max_correction_change = 5
        correction = max(
            min(previous_correction + max_correction_change, correction), 
            previous_correction - max_correction_change
        )
        previous_correction = correction

        # 좌우 모터 속도 계산
        left_motor_speed = current_speed + correction - bias
        right_motor_speed = current_speed - correction + bias

        # 속도 변화율 제한
        if current_speed < 35:  # 저속 상태에서 제한 강화
            max_speed_change = 3
        else:
            max_speed_change = 7

        left_motor_speed = max(
            min(previous_left_speed + max_speed_change, left_motor_speed), 
            previous_left_speed - max_speed_change
        )
        right_motor_speed = max(
            min(previous_right_speed + max_speed_change, right_motor_speed), 
            previous_right_speed - max_speed_change
        )
        previous_left_speed = left_motor_speed
        previous_right_speed = right_motor_speed

        # 모터 최소 출력 설정
        min_motor_output = 25
        left_motor_speed = max(left_motor_speed, min_motor_output) if left_motor_speed > 0 else min(left_motor_speed, -min_motor_output)
        right_motor_speed = max(right_motor_speed, min_motor_output) if right_motor_speed > 0 else min(right_motor_speed, -min_motor_output)

        # 모터 속도 제한
        left_motor_speed = max(min(left_motor_speed, 100), -100)
        right_motor_speed = max(min(right_motor_speed, 100), -100)

        left_motor.dc(left_motor_speed)
        right_motor.dc(right_motor_speed)

    left_motor.hold()
    right_motor.hold()


async def fwd_asmc(
    target_heading, 
    final_distance, 
    start_speed, 
    max_speed, 
    end_speed, 
    decel_start_distance, 
    c1=1.0,  # 낮은 위치 오차 중요도
    c2=1.0, 
    k_min=10, 
    k_max=50, 
    lambda_gain=1.0,
    epsilon=0.5, 
    kp=1.0, 
    bias=1 
):
    """
    Adaptive Sliding Mode Control + c1 안정화.
    """
    left_motor.reset_angle(0)
    right_motor.reset_angle(0)
    hub.imu.reset_heading(0)

    previous_control_input = 0  # 이전 제어 입력 저장

    def adaptive_gain(s):
        """슬라이딩 면에 따라 제어 강도 조정"""
        return max(k_min, min(k_max, k_min + abs(s) * lambda_gain))

    while abs(left_motor.angle()) < final_distance:
        left_distance = abs(left_motor.angle())
        remaining_distance = final_distance - left_distance
        current_heading = hub.imu.heading()

        # 속도 계산 (가속/감속 구분)
        if left_distance < decel_start_distance:  # 가속 단계
            current_speed = min(start_speed + (left_distance / 100) * max_speed, max_speed)
        else:  # 감속 단계
            scale = remaining_distance / (final_distance - decel_start_distance)
            current_speed = end_speed + (max_speed - end_speed) * scale

        # 슬라이딩 면 계산
        s = c1 * (target_heading - current_heading)

        # 적응형 이득 계산
        k = adaptive_gain(s)

        # Boundary Layer 기법으로 제어 입력 계산
        if abs(s) > epsilon:
            control_input = -k * umath.copysign(1, s)  # 경계층 밖에서는 비선형 제어
        else:
            control_input = -k * s / epsilon  # 경계층 안에서는 선형 제어

        # 제어 입력 변화 완화
        control_input = previous_control_input * 0.8 + control_input * 0.2
        previous_control_input = control_input

        # PID 보조 제어 (비례 제어만)
        heading_error = target_heading - current_heading
        pid_correction = kp * heading_error

        # 모터 속도 계산
        left_motor_speed = current_speed - control_input + pid_correction + bias
        right_motor_speed = current_speed + control_input - pid_correction - bias

        # 모터 속도 제한
        left_motor_speed = max(min(left_motor_speed, 100), -100)
        right_motor_speed = max(min(right_motor_speed, 100), -100)

        # 최소 모터 출력 설정
        min_motor_output = max(15, current_speed // 2)
        left_motor_speed = max(left_motor_speed, min_motor_output) if left_motor_speed > 0 else min(left_motor_speed, -min_motor_output)
        right_motor_speed = max(right_motor_speed, min_motor_output) if right_motor_speed > 0 else min(right_motor_speed, -min_motor_output)

        # 모터 구동
        left_motor.dc(left_motor_speed)
        right_motor.dc(right_motor_speed)

        # 대기 시간
        await wait(5)

    # 종료 시 정지
    left_motor.hold()
    right_motor.hold()
    print(left_motor.angle())





async def fwd_indi_with_motor_balance(
    target_heading, 
    final_angle, 
    start_speed, 
    max_speed, 
    end_speed, 
    decel_start_angle, 
    accel_rate, 
    reset_gyro=True, 
    stall_stop=True,
    kp_motor=0.5, 
    kd_motor=0.1,
    ki_motor=0.01,  # 적분 항목 추가
    tolerance=2  # 도착 위치 허용 오차
):
    """
    INDI + 모터 각도 기반 PD + PI 제어 (드리프트 보정 및 초기값 유지)
    """
    # 고정된 제어 상수
    kp_base = 3
    kd_base = 0.05
    ki_base = 0.001
    adapt_rate = 0.0001
    integral_max = 50  # 적분 항목 누적 제한

    stopwatch = StopWatch()
    last_movement_time = stopwatch.time()

    # 자이로 초기화 여부에 따라 초기값 저장
    initial_heading = hub.imu.heading() if not reset_gyro else 0
    if reset_gyro:
        hub.imu.reset_heading(0)

    # 모터 초기화
    left_motor.reset_angle(0)
    right_motor.reset_angle(0)

    current_speed = abs(start_speed)
    max_speed = abs(max_speed)
    end_speed = abs(end_speed)
    accel_rate = abs(accel_rate)

    prev_angle_error = 0
    integral_error = 0
    prev_error = 0

    kp_min, kp_max = 0.5 * kp_base, 2 * kp_base
    kd_min, kd_max = 0.5 * kd_base, 2 * kd_base

    while abs(left_motor.angle()) < final_angle:
        left_angle = abs(left_motor.angle())
        remaining_distance = final_angle - left_angle

        # 가속 및 감속 처리
        if left_angle >= decel_start_angle:
            scale = remaining_distance / (final_angle - decel_start_angle)
            current_speed = end_speed + (max_speed - end_speed) * scale
        else:
            if current_speed < max_speed:
                current_speed += accel_rate
                current_speed = min(current_speed, max_speed)

        # 속도에 따른 제어 상수 조정
        if current_speed < 20:  # 속도가 낮을 때 정밀 제어
            kp = kp_base * 0.5
            kd = kd_base * 0.5
            ki = ki_base * 0.5
        else:
            kp = kp_base
            kd = kd_base
            ki = ki_base

        # 초기값을 기준으로 자이로 오차 계산
        current_heading = hub.imu.heading()
        error = (current_heading - initial_heading) - target_heading
        error_derivative = error - prev_error
        prev_error = error

        # 적분 항목 계산 및 제한
        integral_error += error
        integral_error = max(min(integral_error, integral_max), -integral_max)

        # INDI 제어: 현재 오차, 변화율, 적분 항목 기반 보정값 계산
        correction = kp * error + kd * error_derivative + ki * integral_error

        # 모터 각도 기반 보정 (PD 제어)
        angle_error = left_motor.angle() - right_motor.angle()
        angle_derivative = angle_error - prev_angle_error
        prev_angle_error = angle_error

        angle_correction = kp_motor * angle_error + kd_motor * angle_derivative

        # 전체 보정값 계산
        total_correction = correction + angle_correction

        # 모터 출력 설정
        left_motor.dc(current_speed - total_correction)
        right_motor.dc(current_speed + total_correction)

        # 도착 위치 허용 오차 확인
        if remaining_distance < tolerance:
            break

        # 스톨 조건 확인
        if stall_stop:
            if abs(left_angle - abs(right_motor.angle())) > 100:
                break
            current_time = stopwatch.time()
            left_sp = abs(left_motor.speed())
            if (current_time - last_movement_time) > 200 and left_sp < 10:
                break
            if left_sp > 10:
                last_movement_time = current_time

        # 대기 시간
        #await wait(5)

    # 모터 정지
    left_motor.hold()
    right_motor.hold()


async def fwd_lqr_motor(
    target_heading, 
    final_angle, 
    start_speed, 
    max_speed, 
    end_speed, 
    decel_start_angle, 
    accel_rate, 
    reset_gyro=True, 
    stall_stop=True,
    K=[2.0, 0.5]  # LQR 이득 (헤딩 오차, 각도 차이)
):
    """
    LQR 기반 전진 함수 (오른쪽 회전 문제 수정)
    """
    # 고정된 설정
    stopwatch = StopWatch()
    last_movement_time = stopwatch.time()

    # 자이로 초기화 여부에 따라 리셋
    initial_heading = hub.imu.heading() if not reset_gyro else 0
    if reset_gyro:
        hub.imu.reset_heading(0)

    # 모터 초기화
    left_motor.reset_angle(0)
    right_motor.reset_angle(0)

    current_speed = abs(start_speed)
    max_speed = abs(max_speed)
    end_speed = abs(end_speed)
    accel_rate = abs(accel_rate)

    while abs(left_motor.angle()) < final_angle:
        left_angle = abs(left_motor.angle())
        remaining_distance = final_angle - left_angle

        # 가속 및 감속 처리
        if left_angle >= decel_start_angle:
            scale = remaining_distance / (final_angle - decel_start_angle)
            current_speed = end_speed + (max_speed - end_speed) * scale
        else:
            if current_speed < max_speed:
                current_speed += accel_rate
                current_speed = min(current_speed, max_speed)

        # 상태 변수 계산
        heading_error = target_heading - (hub.imu.heading() - initial_heading)  # 헤딩 오차
        angle_error = right_motor.angle() - left_motor.angle()  # 모터 각도 차이 (수정)

        # LQR 제어 입력 계산
        correction = K[0] * heading_error + K[1] * angle_error  # 보정 방향 확인

        # 모터 출력 설정
        left_motor.dc(current_speed + correction)  # 수정: 보정 방향 반전
        right_motor.dc(current_speed - correction)  # 수정: 보정 방향 반전

        # 도착 위치 허용 오차 확인
        if remaining_distance < 2:  # 허용 오차 2도
            break

        # 스톨 조건 확인
        if stall_stop:
            if abs(left_angle - abs(right_motor.angle())) > 100:
                break
            current_time = stopwatch.time()
            left_sp = abs(left_motor.speed())
            if (current_time - last_movement_time) > 200 and left_sp < 10:
                break
            if left_sp > 10:
                last_movement_time = current_time

        # 대기 시간
        #await wait(5)

    # 모터 정지
    left_motor.hold()
    right_motor.hold()





