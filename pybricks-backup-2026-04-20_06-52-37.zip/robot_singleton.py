from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor
from pybricks.parameters import Port, Direction, Stop, Color
from pybricks.tools import StopWatch

class Robot:
    _instance = None

    def __init__(self):
        self.hub = PrimeHub()
        self.left_motor = Motor(Port.F, Direction.COUNTERCLOCKWISE)
        self.right_motor = Motor(Port.B, Direction.CLOCKWISE)
        self.left_arm = Motor(Port.C)
        self.right_arm = Motor(Port.D)
        self.left_color = ColorSensor(Port.A)
        self.right_color = ColorSensor(Port.E)
        self.stopwatch = StopWatch()  # StopWatch 인스턴스 생성
        self.hub.imu.settings(angular_velocity_threshold=2.0, acceleration_threshold=300)
        print("IMU 설정 완료")

    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def get_stopwatch(self):
        return self.stopwatch  # 인스턴스 메서드로 stopwatch 반환

def get_robot():
    return Robot.get_instance()